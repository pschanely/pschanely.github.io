# crosshair: analysis_kind=icontract
